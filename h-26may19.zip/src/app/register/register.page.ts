import { ApiService } from './../services/api.service';

import { Component, OnInit } from '@angular/core';
import {NgForm, Validators, FormBuilder, FormGroup, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {

  regform: FormGroup;
  public states: any[];
  public districts: any[];
  public cities: any[];

  public selectedDistricts: any[];

  constructor(private apiService: ApiService) {
    this.initializeState();
    this.initializeDistrict();

    this.regform = new FormGroup({
      first_name: new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(3)
      ])),
      lname:new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(3)
      ])),
      email:new FormControl('', Validators.compose([
        Validators.required,
        Validators.email
      ])),
      address:new FormControl('', Validators.compose([
        Validators.required,
        Validators.minLength(4)
      ])),
      birth_date: new FormControl('', Validators.required),
      gender: new FormControl('false'),
      age: new FormControl('false'),
      occupation: new FormControl('false'),
      password: new FormControl('', Validators.required),
      sState: new FormControl('', Validators.required),
      sDistrict: new FormControl('', Validators.required)
    });



   }

  ngOnInit() {
  }



  initializeState() {

    this.apiService.division().subscribe((data) =>{

      this.states = data;
      console.log(this.states);
    });

  }

  initializeDistrict() {

    this.apiService.district().subscribe((data) =>{
      this.districts = data;
      console.log(this.districts);
    });

  }

  setDistrictValues(sState) {
    console.log(sState);
    this.selectedDistricts = this.districts.filter(districts => districts.division_id == sState);
  }

  register(form: NgForm) {

    let data:any = {

      'first_name' : form.value.first_name,
      'last_name' : form.value.last_name,
      'email' : form.value.email,
      'phone' : form.value.phone,
      'address' : form.value.address,
      'division_name' : form.value.sState.name,
      'district_name' : form.value.sDistrict.name,
      'birth_date' : (form.value.birth_date).split('T')[0],
      'gender' :  form.value.gender,
      'age' : form.value.age,
      'occupation' : form.value.occupation,
      'password' : form.value.password,

    };

    console.log(data);


    this.apiService.register(data).subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      }
    );
  }

}
