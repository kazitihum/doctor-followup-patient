import { ApiService } from './../services/api.service';

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor( private apiService: ApiService,private router: Router) { }

  ngOnInit() {
  }

  login(form: NgForm) {

    this.apiService.login(form.value.email, form.value.password).subscribe(
      data => {
        console.log(data);
        this.router.navigateByUrl('/tabs');
      },
      error => {
        console.log(error);
        this.router.navigateByUrl('/tabs');
      }
    );
  }



}
