import { Component, OnInit } from '@angular/core';
import { ApiService } from './../services/api.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.page.html',
  styleUrls: ['./user-profile.page.scss'],
})
export class UserProfilePage implements OnInit {

  userInfo = '';

  constructor(private apiService: ApiService) {
    this.apiService.userDatabyId(1).subscribe(
      data => {
        console.log(data);
        this.userInfo = data;
      },
      error => {
        console.log(error);
      }
    );
   }

  ngOnInit() {
  }

  profile() {
   
  }




}
