import { Component } from '@angular/core';
import { ApiService } from './../services/api.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  docData:any='';
  searchTerm: string = '';

  constructor( private apiService: ApiService) { }

  doctorSearch(name){

    console.log(name);
    this.apiService.doctorSearch(this.searchTerm).subscribe(
      data => {
        console.log(data);
        this.docData = data;
      },
      error => {
        console.log(error);
      }
    );
  }


}
