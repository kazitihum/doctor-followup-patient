import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-call',
  templateUrl: './appointment-call.page.html',
  styleUrls: ['./appointment-call.page.scss'],
})
export class AppointmentCallPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
