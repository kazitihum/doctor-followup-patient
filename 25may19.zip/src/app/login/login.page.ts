import { ApiService } from './../services/api.service';

import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor( private apiService: ApiService) { }

  ngOnInit() {
  }

  login(form: NgForm) {

    this.apiService.login(form.value.email, form.value.password).subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      }
    );
  }



}
