import { PassdataService } from './../passdata/passdata.service';
import { Component } from '@angular/core';
import { ApiService } from './../services/api.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  docData:any='';
  searchTerm: string = '';

  constructor( private apiService: ApiService, private passdata: PassdataService, private router: Router) { }

  doctorSearch(name) {

    console.log(name);
    this.apiService.doctorSearch(this.searchTerm).subscribe(
      data => {
        console.log(data);
        this.docData = data;
      },
      error => {
        console.log(error);
      }
    );
  }

  doctorDetails(data) {

    this.passdata.setData('docdetails', data);
    this.router.navigateByUrl('/doctor-profile');
  }


}
