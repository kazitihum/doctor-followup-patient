import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-create-followup',
  templateUrl: './create-followup.page.html',
  styleUrls: ['./create-followup.page.scss'],
})
export class CreateFollowupPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  createFollowup(){
    
  }

}
